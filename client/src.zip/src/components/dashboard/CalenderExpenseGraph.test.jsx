import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { CalenderExpenseGraph } from './CalenderExpenseGraph';
import * as ExpenseServices from '../../services/expenseServices';

// Mock the dependent services and hooks
jest.mock('../../services/expenseServices', () => ({
  getUserDailyExpService: jest.fn(),
  getUserMonthlyExpService: jest.fn(),
}));
jest.mock('../../theme/hooks/useResponsive', () => () => true);
jest.mock('react-chartjs-2', () => ({
  Line: () => null, // Mock Line as a no-op component
}));

describe('CalenderExpenseGraph', () => {
  beforeEach(() => {
    ExpenseServices.getUserMonthlyExpService.mockResolvedValue({ data: { data: [] } });
    ExpenseServices.getUserDailyExpService.mockResolvedValue({ data: { data: [] } });
    localStorage.setItem('profile', JSON.stringify({ emailId: 'test@example.com' }));
  });

  afterEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  test('renders without crashing', () => {
    render(<CalenderExpenseGraph />);
    expect(screen.getByText(/Expense Graph/)).toBeInTheDocument();
  });

  test('displays loading initially', () => {
    render(<CalenderExpenseGraph />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  test('toggle between monthly and daily views', async () => {
    render(<CalenderExpenseGraph />);
    const switchEl = screen.getByRole('checkbox');
    userEvent.click(switchEl);
    await waitFor(() => {
      expect(screen.getByText('Daily View')).toBeInTheDocument();
    });
    userEvent.click(switchEl);
    await waitFor(() => {
      expect(screen.getByText('Monthly View')).toBeInTheDocument();
    });
  });

  test('shows alert banner when there is an alert', async () => {
    ExpenseServices.getUserMonthlyExpService.mockResolvedValueOnce({
      data: {
        data: [],
        alert: true,
        alertMessage: 'Error fetching data'
      }
    });
    render(<CalenderExpenseGraph />);
    await waitFor(() => {
      expect(screen.getByText('Error fetching data')).toBeInTheDocument();
    });
  });
});
